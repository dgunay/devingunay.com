<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'frontPage', '_controller' => 'App\\Controller\\FrontPageController::frontPage'], null, null, null, false, false, null]],
        '/goodbans' => [[['_route' => 'goodBans', '_controller' => 'App\\Controller\\GoodBansController::goodBans'], null, null, null, false, false, null]],
        '/hobbies' => [[['_route' => 'hobbies', '_controller' => 'App\\Controller\\HobbiesController::hobbies'], null, null, null, false, false, null]],
        '/about' => [[['_route' => 'about', '_controller' => 'App\\Controller\\AboutController::about'], null, null, null, false, false, null]],
        '/blog' => [[['_route' => 'blogFront', '_controller' => 'App\\Controller\\Blog\\BlogController::blogFront'], null, null, null, false, false, null]],
        '/blog/search' => [[['_route' => 'blogSearch', '_controller' => 'App\\Controller\\Blog\\BlogController::search'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/blog/(?'
                    .'|post/([^/]++)(*:64)'
                    .'|archive(?:/([^/]++)(?:/([^/]++))?)?(*:106)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        64 => [[['_route' => 'blogPost', '_controller' => 'App\\Controller\\Blog\\BlogController::blogPost'], ['publishTime'], null, null, false, true, null]],
        106 => [
            [['_route' => 'blogArchive', 'year' => null, 'month' => null, '_controller' => 'App\\Controller\\Blog\\BlogController::archive'], ['year', 'month'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
