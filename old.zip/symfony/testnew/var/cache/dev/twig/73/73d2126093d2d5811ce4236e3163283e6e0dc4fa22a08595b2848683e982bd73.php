<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog_base.html.twig */
class __TwigTemplate_677234d803c2a7d9fbe23d6e3d9894b8d3e07316cc35dc499aef5a6405f483de extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'content' => [$this, 'block_content'],
            'sidebar' => [$this, 'block_sidebar'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog_base.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "blog_base.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " Devin's Blog ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
<!-- Styles blockquotes in a more pleasing way -->
<style>
  blockquote {
    border-left: 5px solid #ccc;
    background: #f9f9f9;
  }

  blockquote>p {
    margin: 1.5em 10px;
    padding: 10px;
  }
</style>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 22
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 23
        $this->displayParentBlock("body", $context, $blocks);
        echo "

<!-- Top row banner -->
<div class=\"container\" style=\"margin-bottom: 40px;margin-top: 40px;\">
  <h1 class=\"display-3\">Devin's Blog</h1>
</div>

<!-- Main container -->
<div class=\"container\">
  <div class=\"row\">
    <!-- Main content area -->
    <div class=\"col-md-9 mb-sm-5\">
      ";
        // line 35
        $this->displayBlock('content', $context, $blocks);
        // line 57
        echo "    </div>

    <!-- Side bar -->
    <div class=\"col-md-3\">
      ";
        // line 61
        $this->displayBlock('sidebar', $context, $blocks);
        // line 64
        echo "    </div>
  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 35
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 36
        echo "      ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 36, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 37
            echo "      <!-- Render the post -->
      ";
            // line 38
            $this->loadTemplate("post.html.twig", "blog_base.html.twig", 38)->display(twig_array_merge($context, ["post" => $context["post"]]));
            // line 39
            echo "      <hr />
      ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "
      <!-- Prev/Next links -->
      <div class=\"row justify-content-between\">
        <div class=\"col-sm-1\">
          ";
        // line 45
        if ((array_key_exists("prev", $context) &&  !(null === (isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 45, $this->source); })())))) {
            // line 46
            echo "          <a href=\"/blog/post/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 46, $this->source); })()), "publishTime", [], "any", false, false, false, 46), "html", null, true);
            echo "\">Previous</a>
          ";
        }
        // line 48
        echo "        </div>
        <!-- <div class=\"col-sm-1\"></div> -->
        <div class=\"col-sm-1\">
          ";
        // line 51
        if ((array_key_exists("next", $context) &&  !(null === (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 51, $this->source); })())))) {
            // line 52
            echo "          <a href=\"/blog/post/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 52, $this->source); })()), "publishTime", [], "any", false, false, false, 52), "html", null, true);
            echo "\">Next</a>
          ";
        }
        // line 54
        echo "        </div>
      </div>
      ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 61
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "sidebar"));

        // line 62
        echo "      ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("App\\Controller\\Blog\\SideBarController::renderSideBar"));
        echo "
      ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  228 => 62,  221 => 61,  212 => 54,  206 => 52,  204 => 51,  199 => 48,  193 => 46,  191 => 45,  185 => 41,  170 => 39,  168 => 38,  165 => 37,  147 => 36,  140 => 35,  130 => 64,  128 => 61,  122 => 57,  120 => 35,  105 => 23,  98 => 22,  76 => 6,  69 => 5,  56 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block title %} Devin's Blog {% endblock %}

{% block stylesheets %}
{{ parent() }}
<!-- Styles blockquotes in a more pleasing way -->
<style>
  blockquote {
    border-left: 5px solid #ccc;
    background: #f9f9f9;
  }

  blockquote>p {
    margin: 1.5em 10px;
    padding: 10px;
  }
</style>

{% endblock %}

{% block body %}
{{ parent() }}

<!-- Top row banner -->
<div class=\"container\" style=\"margin-bottom: 40px;margin-top: 40px;\">
  <h1 class=\"display-3\">Devin's Blog</h1>
</div>

<!-- Main container -->
<div class=\"container\">
  <div class=\"row\">
    <!-- Main content area -->
    <div class=\"col-md-9 mb-sm-5\">
      {% block content %}
      {% for post in posts %}
      <!-- Render the post -->
      {% include \"post.html.twig\" with { \"post\" : post } %}
      <hr />
      {% endfor %}

      <!-- Prev/Next links -->
      <div class=\"row justify-content-between\">
        <div class=\"col-sm-1\">
          {% if prev is defined and prev is not null %}
          <a href=\"/blog/post/{{prev.publishTime}}\">Previous</a>
          {% endif %}
        </div>
        <!-- <div class=\"col-sm-1\"></div> -->
        <div class=\"col-sm-1\">
          {% if next is defined and next is not null %}
          <a href=\"/blog/post/{{next.publishTime}}\">Next</a>
          {% endif %}
        </div>
      </div>
      {% endblock content %}
    </div>

    <!-- Side bar -->
    <div class=\"col-md-3\">
      {% block sidebar %}
      {{ render(controller('App\\\\Controller\\\\Blog\\\\SideBarController::renderSideBar')) }}
      {% endblock %}
    </div>
  </div>
</div>
{% endblock %}", "blog_base.html.twig", "/var/www/symfony/testnew/templates/blog_base.html.twig");
    }
}
