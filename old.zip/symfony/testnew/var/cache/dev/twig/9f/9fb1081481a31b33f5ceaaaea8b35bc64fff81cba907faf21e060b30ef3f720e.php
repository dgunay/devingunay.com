<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog_postnotfound.html.twig */
class __TwigTemplate_a39c4194dd818349b78a57f171083015148d2066210abe5ee0843f629acf0ae2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "blog_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog_postnotfound.html.twig"));

        $this->parent = $this->loadTemplate("blog_base.html.twig", "blog_postnotfound.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "<h1>Post Not Found</h1>
<hr/>
<p>Sorry, the post you were looking for could not be found.</p>

";
        // line 8
        if ( !twig_test_empty((isset($context["nearbyPosts"]) || array_key_exists("nearbyPosts", $context) ? $context["nearbyPosts"] : (function () { throw new RuntimeError('Variable "nearbyPosts" does not exist.', 8, $this->source); })()))) {
            // line 9
            echo "<p>Were you perhaps looking for posts at these times?:</p>
<ul>
\t";
            // line 11
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["nearbyPosts"]) || array_key_exists("nearbyPosts", $context) ? $context["nearbyPosts"] : (function () { throw new RuntimeError('Variable "nearbyPosts" does not exist.', 11, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
                // line 12
                echo "\t<li>
\t\t<b>";
                // line 13
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "publishTime", [], "any", false, false, false, 13), "m/d/Y - g:i a"), "html", null, true);
                echo ": </b>
\t\t<a href=\"/blog/post/";
                // line 14
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "publishTime", [], "any", false, false, false, 14), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "title", [], "any", false, false, false, 14), "html", null, true);
                echo "</a>
\t</li>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "</ul>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog_postnotfound.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 17,  82 => 14,  78 => 13,  75 => 12,  71 => 11,  67 => 9,  65 => 8,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"blog_base.html.twig\" %}

{% block content %}
<h1>Post Not Found</h1>
<hr/>
<p>Sorry, the post you were looking for could not be found.</p>

{% if nearbyPosts is not empty %}
<p>Were you perhaps looking for posts at these times?:</p>
<ul>
\t{% for post in nearbyPosts %}
\t<li>
\t\t<b>{{ post.publishTime|date(\"m/d/Y - g:i a\") }}: </b>
\t\t<a href=\"/blog/post/{{post.publishTime}}\">{{ post.title }}</a>
\t</li>
\t{% endfor %}
</ul>
{% endif %}
{% endblock content %}", "blog_postnotfound.html.twig", "/var/www/symfony/testnew/templates/blog_postnotfound.html.twig");
    }
}
