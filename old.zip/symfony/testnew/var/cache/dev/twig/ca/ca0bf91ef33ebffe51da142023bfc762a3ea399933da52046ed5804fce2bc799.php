<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* navbar.html.twig */
class __TwigTemplate_8abdfbe85311be1d50e046a98e9b3aa82cf1a263947daca905064e82ba3ea4df extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "navbar.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
  <a class=\"navbar-brand\" href=\"/\">Devin Günay</a>
  <button aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" class=\"navbar-toggler\" data-target=\"#navbarSupportedContent\" data-toggle=\"collapse\" type=\"button\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
    <ul
      class=\"navbar-nav mr-auto\">
      ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["navBarLinks"]) || array_key_exists("navBarLinks", $context) ? $context["navBarLinks"] : (function () { throw new RuntimeError('Variable "navBarLinks" does not exist.', 9, $this->source); })()));
        foreach ($context['_seq'] as $context["displayName"] => $context["link"]) {
            // line 10
            echo "        <li class=\"nav-item ";
            if ((0 === twig_compare((isset($context["currentPage"]) || array_key_exists("currentPage", $context) ? $context["currentPage"] : (function () { throw new RuntimeError('Variable "currentPage" does not exist.', 10, $this->source); })()), $context["link"]))) {
                echo " active ";
            }
            echo "\">
          <a class=\"nav-link\" href=\"";
            // line 11
            echo twig_escape_filter($this->env, $context["link"], "html", null, true);
            echo "\">
            ";
            // line 12
            echo twig_escape_filter($this->env, $context["displayName"], "html", null, true);
            echo "
          </a>
        </li>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['displayName'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    </ul>
    ";
        // line 18
        echo "    ";
        // line 19
        echo "
    <!-- Minecraft server status -->
    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("App\\Controller\\RunningProcessController::mineCraft"));
        echo "
  </div>
</nav>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 21,  80 => 19,  78 => 18,  75 => 16,  65 => 12,  61 => 11,  54 => 10,  50 => 9,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
  <a class=\"navbar-brand\" href=\"/\">Devin Günay</a>
  <button aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" class=\"navbar-toggler\" data-target=\"#navbarSupportedContent\" data-toggle=\"collapse\" type=\"button\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
    <ul
      class=\"navbar-nav mr-auto\">
      {% for displayName, link in navBarLinks %}
        <li class=\"nav-item {% if currentPage == link %} active {% endif %}\">
          <a class=\"nav-link\" href=\"{{ link }}\">
            {{ displayName }}
          </a>
        </li>
      {% endfor %}
    </ul>
    {# TODO: a search bar will go here eventually #}
    {# <small class=\"text-muted\">Site under construction</small> #}

    <!-- Minecraft server status -->
    {{ render(controller('App\\\\Controller\\\\RunningProcessController::mineCraft')) }}
  </div>
</nav>
", "navbar.html.twig", "/var/www/symfony/testnew/templates/navbar.html.twig");
    }
}
