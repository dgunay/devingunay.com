<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* hobbies.html.twig */
class __TwigTemplate_02a7f4efcea5935aea12d80844dba7e0ea1445c2b785d120c906cfe04a0f68fd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "hobbies.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "hobbies.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " Devin Gunay ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        $this->displayParentBlock("body", $context, $blocks);
        echo "

<div class=\"jumbotron\">
  <div class=\"container\">
    <h1 class=\"display-3\">Guides </h1>
    <p class=\"lead\">
      Competitive guides for Smash 4 and League of Legends.
    </p>
    <p class=\"lead\">
      No guarantees that any of my writing is current for
      for the meta of either game!
    </p>
  </div>
</div>

<div class=\"container\">
  <div class=\"row\" style=\"bottom: 20px;\">
    <h1 class=\"text-left display-4\">Video Games</h1>
  </div>
  <div class=\"row\">
    <div class=\"card-group\">
      <div class=\"col-md-3\">
        <div class=\"card\">
          <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marth.jpg"), "html", null, true);
        echo "\" class=\"card-img-top\" style\"max-width:70%;height:auto;\">
          <div class=\"card-body\">
            <h3 class=\"card-title\">Smash 4</h3>
            <p class=\"lead\">Character-focused guides.</p>
          </div>
          <div class=\"card-footer text-center\">
            <a href=\"https://drive.google.com/open?id=0B4vWYBgV8fPPdkxGV3JabXpZU2M\" class=\"btn btn-secondary\">Read on
              Google Docs</a>
          </div>
        </div>
      </div>
      <div class=\"col-md-3\">
        <div class=\"card\">
          <img src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/zedyas.png"), "html", null, true);
        echo "\" class=\"card-img-top\" style\"max-width:70%;height:auto;\">
          <div class=\"card-body\">
            <h3 class=\"card-title\">League of Legends</h3>
            <p class=\"lead\">Character and macro-focused guides, as well as essays on phenomena of the game.</p>
          </div>
          <div class=\"card-footer text-center\">
            <a href=\"https://drive.google.com/open?id=0B4vWYBgV8fPPMGNIa09kNWtXOTQ\" class=\"btn btn-secondary\">Read on
              Google Docs</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "hobbies.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 42,  99 => 29,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}

{% block title %} Devin Gunay {% endblock %}

{% block body %}
{{ parent() }}

<div class=\"jumbotron\">
  <div class=\"container\">
    <h1 class=\"display-3\">Guides </h1>
    <p class=\"lead\">
      Competitive guides for Smash 4 and League of Legends.
    </p>
    <p class=\"lead\">
      No guarantees that any of my writing is current for
      for the meta of either game!
    </p>
  </div>
</div>

<div class=\"container\">
  <div class=\"row\" style=\"bottom: 20px;\">
    <h1 class=\"text-left display-4\">Video Games</h1>
  </div>
  <div class=\"row\">
    <div class=\"card-group\">
      <div class=\"col-md-3\">
        <div class=\"card\">
          <img src=\"{{ asset('img/marth.jpg') }}\" class=\"card-img-top\" style\"max-width:70%;height:auto;\">
          <div class=\"card-body\">
            <h3 class=\"card-title\">Smash 4</h3>
            <p class=\"lead\">Character-focused guides.</p>
          </div>
          <div class=\"card-footer text-center\">
            <a href=\"https://drive.google.com/open?id=0B4vWYBgV8fPPdkxGV3JabXpZU2M\" class=\"btn btn-secondary\">Read on
              Google Docs</a>
          </div>
        </div>
      </div>
      <div class=\"col-md-3\">
        <div class=\"card\">
          <img src=\"{{ asset('img/zedyas.png') }}\" class=\"card-img-top\" style\"max-width:70%;height:auto;\">
          <div class=\"card-body\">
            <h3 class=\"card-title\">League of Legends</h3>
            <p class=\"lead\">Character and macro-focused guides, as well as essays on phenomena of the game.</p>
          </div>
          <div class=\"card-footer text-center\">
            <a href=\"https://drive.google.com/open?id=0B4vWYBgV8fPPMGNIa09kNWtXOTQ\" class=\"btn btn-secondary\">Read on
              Google Docs</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
{% endblock %}", "hobbies.html.twig", "/var/www/symfony/testnew/templates/hobbies.html.twig");
    }
}
