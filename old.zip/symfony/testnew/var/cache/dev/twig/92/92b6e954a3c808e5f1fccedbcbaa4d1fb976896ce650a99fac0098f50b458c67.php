<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* frontpage.html.twig */
class __TwigTemplate_ae41ee755f5e4fb8a455d14d95eae7668a384f93d7eb4c33f433b264e80f579d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "frontpage.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "frontpage.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " Devin Gunay ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        $this->displayParentBlock("body", $context, $blocks);
        echo "

<div class=\"jumbotron\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md\">
        <h1 class=\"display-2\"> Devin Günay </h1>
      </div>
    </div>
  </div>
</div>

<div class=\"container\">
  <div class=\"row justify-content-md-left align-items-center\">
    <div class=\"col-md-6\">
      <h2 class=\"display-4\">
        Developer
      </h2>
      <p class=\"lead\">
        Devin strives to deliver clean, optimal solutions with the
        right tools for the job. He specializes in PHP but is always willing
        to take on the next big language, framework, or paradigm.
      </p>
    </div>
    <div class=\"col-md-6\">
      <img src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/img/code_crop.jpg"), "html", null, true);
        echo "\" alt=\"\" class=\"img-fluid\">
    </div>
  </div>
  <div class=\"row justify-content-md-end align-items-center mt-3\">
    <div class=\"col-md-6\">
      <h2 class=\"display-4\">
        Musician
      </h2>
      <p class=\"lead\">
        Devin is a capable jazz pianist in both solo and group settings. If
        he doesn't know your tune, put a lead sheet in front of him and it's
        as though he already did. Devin specializes in an authentic, pre-40s
        stride sound when performing solo.
      </p>
    </div>
    <div class=\"col-md-6\">
      <img src=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/img/music_crop.jpg"), "html", null, true);
        echo "\" alt=\"\" class=\"img-fluid\">
    </div>
  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "frontpage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 46,  101 => 30,  73 => 5,  66 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %} Devin Gunay {% endblock %}
{% block body %}
{{ parent() }}

<div class=\"jumbotron\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md\">
        <h1 class=\"display-2\"> Devin Günay </h1>
      </div>
    </div>
  </div>
</div>

<div class=\"container\">
  <div class=\"row justify-content-md-left align-items-center\">
    <div class=\"col-md-6\">
      <h2 class=\"display-4\">
        Developer
      </h2>
      <p class=\"lead\">
        Devin strives to deliver clean, optimal solutions with the
        right tools for the job. He specializes in PHP but is always willing
        to take on the next big language, framework, or paradigm.
      </p>
    </div>
    <div class=\"col-md-6\">
      <img src=\"{{ asset('/img/code_crop.jpg') }}\" alt=\"\" class=\"img-fluid\">
    </div>
  </div>
  <div class=\"row justify-content-md-end align-items-center mt-3\">
    <div class=\"col-md-6\">
      <h2 class=\"display-4\">
        Musician
      </h2>
      <p class=\"lead\">
        Devin is a capable jazz pianist in both solo and group settings. If
        he doesn't know your tune, put a lead sheet in front of him and it's
        as though he already did. Devin specializes in an authentic, pre-40s
        stride sound when performing solo.
      </p>
    </div>
    <div class=\"col-md-6\">
      <img src=\"{{ asset('/img/music_crop.jpg') }}\" alt=\"\" class=\"img-fluid\">
    </div>
  </div>
</div>
{% endblock %}", "frontpage.html.twig", "/var/www/symfony/testnew/templates/frontpage.html.twig");
    }
}
