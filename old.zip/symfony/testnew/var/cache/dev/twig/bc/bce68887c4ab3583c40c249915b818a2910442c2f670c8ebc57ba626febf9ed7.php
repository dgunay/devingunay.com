<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog_sidebar.html.twig */
class __TwigTemplate_eb574464526689ffe9f1278f69f80287f77b68bb5d7fb854e92515a49bb06f61 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog_sidebar.html.twig"));

        // line 1
        echo "<!-- Links to the 5 most recent posts -->
<div class=\"p-3 border border-top-0 border-bottom-0 rounded\">
  <h4 class=\"display-5\">Recent</h4>
  <ul class=\"list-unstyled\">
    ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 5, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 6
            echo "    <li>
      <!-- link to post -->
      <a href=\"/blog/post/";
            // line 8
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "publishTime", [], "any", false, false, false, 8), "html", null, true);
            echo "\">
        ";
            // line 9
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "title", [], "any", false, false, false, 9), "html", null, true);
            echo "
      </a>

      ";
            // line 12
            if ( !twig_get_attribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 12)) {
                echo " <hr/> ";
            }
            // line 13
            echo "    </li>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "  </ul>
</div>

<!-- Monthly archives -->
<div class=\"p-3 border border-top-0 border-bottom-0 rounded\">
  <h4 class=\"display-5\">
    <a style=\"text-decoration:none; color:#000;\" href=\"/blog/archive\">
      Archive
    </a>
  </h4>
  <ul class=\"list-unstyled\">
    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ymdArchive"]) || array_key_exists("ymdArchive", $context) ? $context["ymdArchive"] : (function () { throw new RuntimeError('Variable "ymdArchive" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["year"] => $context["months"]) {
            // line 27
            echo "    <!-- Year in bold, no blue/underline link styling -->
    <li>
      <a style=\"text-decoration:none; color:#000;\" href=\"/blog/archive/";
            // line 29
            echo twig_escape_filter($this->env, $context["year"], "html", null, true);
            echo "\">
        <b>
          ";
            // line 31
            echo twig_escape_filter($this->env, $context["year"], "html", null, true);
            echo "
        </b>
      </a>
    </li>

    <!-- Reverse the months, keeping their keys the same (reverse(true)) -->
    ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, $context["months"], true));
            foreach ($context['_seq'] as $context["month"] => $context["posts"]) {
                // line 38
                echo "    <li>
      <a href=\"/blog/archive/";
                // line 39
                echo twig_escape_filter($this->env, $context["year"], "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, $context["month"], "html", null, true);
                echo "\">
        <!-- Format month number to full month name -->
        ";
                // line 41
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_converter($this->env, ((($context["year"] . "-") . $context["month"]) . "-01")), "F"), "html", null, true);
                echo "
      </a>
    </li>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['month'], $context['posts'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 45
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['year'], $context['months'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "  </ul>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog_sidebar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 46,  155 => 45,  145 => 41,  138 => 39,  135 => 38,  131 => 37,  122 => 31,  117 => 29,  113 => 27,  109 => 26,  96 => 15,  81 => 13,  77 => 12,  71 => 9,  67 => 8,  63 => 6,  46 => 5,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- Links to the 5 most recent posts -->
<div class=\"p-3 border border-top-0 border-bottom-0 rounded\">
  <h4 class=\"display-5\">Recent</h4>
  <ul class=\"list-unstyled\">
    {% for post in posts %}
    <li>
      <!-- link to post -->
      <a href=\"/blog/post/{{post.publishTime}}\">
        {{ post.title }}
      </a>

      {% if not loop.last %} <hr/> {% endif %}
    </li>
    {% endfor %}
  </ul>
</div>

<!-- Monthly archives -->
<div class=\"p-3 border border-top-0 border-bottom-0 rounded\">
  <h4 class=\"display-5\">
    <a style=\"text-decoration:none; color:#000;\" href=\"/blog/archive\">
      Archive
    </a>
  </h4>
  <ul class=\"list-unstyled\">
    {% for year, months in ymdArchive %}
    <!-- Year in bold, no blue/underline link styling -->
    <li>
      <a style=\"text-decoration:none; color:#000;\" href=\"/blog/archive/{{year}}\">
        <b>
          {{ year }}
        </b>
      </a>
    </li>

    <!-- Reverse the months, keeping their keys the same (reverse(true)) -->
    {% for month, posts in months|reverse(true) %}
    <li>
      <a href=\"/blog/archive/{{year}}/{{month}}\">
        <!-- Format month number to full month name -->
        {{ date(year ~ '-' ~ month ~ '-01')|date('F') }}
      </a>
    </li>
    {% endfor %}
    {% endfor %}
  </ul>
</div>", "blog_sidebar.html.twig", "/var/www/symfony/testnew/templates/blog_sidebar.html.twig");
    }
}
