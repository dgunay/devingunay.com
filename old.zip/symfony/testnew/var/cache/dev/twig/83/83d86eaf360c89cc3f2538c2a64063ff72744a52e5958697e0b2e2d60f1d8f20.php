<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog_showarchive.html.twig */
class __TwigTemplate_002a1c04761a8d0a5ddcb3831e152ba9304010736a5ce10af830b62ac0771c53 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "blog_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog_showarchive.html.twig"));

        $this->parent = $this->loadTemplate("blog_base.html.twig", "blog_showarchive.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "
<h1>Archive</h1>
<hr />

<!-- Show posts in year and month -->
";
        // line 8
        if ( !(null === (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 8, $this->source); })()))) {
            // line 9
            if ( !(null === (isset($context["month"]) || array_key_exists("month", $context) ? $context["month"] : (function () { throw new RuntimeError('Variable "month" does not exist.', 9, $this->source); })()))) {
                // line 10
                echo "<!-- Full name of the month + year -->
<h5>";
                // line 11
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_converter($this->env, ((((isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 11, $this->source); })()) . "-") . (isset($context["month"]) || array_key_exists("month", $context) ? $context["month"] : (function () { throw new RuntimeError('Variable "month" does not exist.', 11, $this->source); })())) . "-01")), "F"), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 11, $this->source); })()), "html", null, true);
                echo "</h5>

<!-- Show all the posts in a month -->
";
                // line 14
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["archive"]) || array_key_exists("archive", $context) ? $context["archive"] : (function () { throw new RuntimeError('Variable "archive" does not exist.', 14, $this->source); })()), (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 14, $this->source); })()), [], "array", false, false, false, 14), (isset($context["month"]) || array_key_exists("month", $context) ? $context["month"] : (function () { throw new RuntimeError('Variable "month" does not exist.', 14, $this->source); })()), [], "array", false, false, false, 14)));
                foreach ($context['_seq'] as $context["day"] => $context["posts"]) {
                    // line 15
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($context["posts"]);
                    foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
                        // line 16
                        echo "<li>
\t<a href=\"/blog/post/";
                        // line 17
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "publishTime", [], "any", false, false, false, 17), "html", null, true);
                        echo "\">
\t\t";
                        // line 18
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["post"], "title", [], "any", false, false, false, 18), "html", null, true);
                        echo "
\t</a>
</li>
";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['day'], $context['posts'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 23
                echo "
";
            } else {
                // line 25
                echo "<h3>";
                echo twig_escape_filter($this->env, (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 25, $this->source); })()), "html", null, true);
                echo "</h3>
<!-- Show months in the year with how many posts they have -->
";
                // line 27
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["archive"]) || array_key_exists("archive", $context) ? $context["archive"] : (function () { throw new RuntimeError('Variable "archive" does not exist.', 27, $this->source); })()), (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 27, $this->source); })()), [], "array", false, false, false, 27), true));
                foreach ($context['_seq'] as $context["month"] => $context["posts"]) {
                    // line 28
                    echo "<h5>
\t<a href=\"/blog/archive/";
                    // line 29
                    echo twig_escape_filter($this->env, (isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 29, $this->source); })()), "html", null, true);
                    echo "/";
                    echo twig_escape_filter($this->env, $context["month"], "html", null, true);
                    echo "\">
\t\t";
                    // line 30
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_converter($this->env, ((((isset($context["year"]) || array_key_exists("year", $context) ? $context["year"] : (function () { throw new RuntimeError('Variable "year" does not exist.', 30, $this->source); })()) . "-") . $context["month"]) . "-01")), "F"), "html", null, true);
                    echo " (";
                    echo twig_escape_filter($this->env, twig_length_filter($this->env, $context["posts"]), "html", null, true);
                    echo ")
\t</a>
</h5>
";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['month'], $context['posts'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 34
                echo "
";
            }
        } else {
            // line 37
            echo "<!-- Show the entire archive -->
";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["archive"]) || array_key_exists("archive", $context) ? $context["archive"] : (function () { throw new RuntimeError('Variable "archive" does not exist.', 38, $this->source); })()));
            foreach ($context['_seq'] as $context["year"] => $context["months"]) {
                // line 39
                echo "<h3>";
                echo twig_escape_filter($this->env, $context["year"], "html", null, true);
                echo "</h3>
";
                // line 40
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, $context["months"], true));
                foreach ($context['_seq'] as $context["month"] => $context["posts"]) {
                    // line 41
                    echo "<h5>
\t<a href=\"/blog/archive/";
                    // line 42
                    echo twig_escape_filter($this->env, $context["year"], "html", null, true);
                    echo "/";
                    echo twig_escape_filter($this->env, $context["month"], "html", null, true);
                    echo "\">
\t\t";
                    // line 43
                    echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_date_converter($this->env, ((($context["year"] . "-") . $context["month"]) . "-01")), "F"), "html", null, true);
                    echo " (";
                    echo twig_escape_filter($this->env, twig_length_filter($this->env, $context["posts"]), "html", null, true);
                    echo ")
\t</a>
</h5>
";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['month'], $context['posts'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['year'], $context['months'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 49
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog_showarchive.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 49,  175 => 43,  169 => 42,  166 => 41,  162 => 40,  157 => 39,  153 => 38,  150 => 37,  145 => 34,  133 => 30,  127 => 29,  124 => 28,  120 => 27,  114 => 25,  110 => 23,  96 => 18,  92 => 17,  89 => 16,  85 => 15,  81 => 14,  73 => 11,  70 => 10,  68 => 9,  66 => 8,  59 => 3,  52 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"blog_base.html.twig\" %}
{% block content %}

<h1>Archive</h1>
<hr />

<!-- Show posts in year and month -->
{% if year is not null %}
{% if month is not null %}
<!-- Full name of the month + year -->
<h5>{{ date(year ~ '-' ~ month ~ '-01')|date('F') }} {{ year }}</h5>

<!-- Show all the posts in a month -->
{% for day, posts in archive[year][month]|reverse %}
{% for post in posts %}
<li>
\t<a href=\"/blog/post/{{post.publishTime}}\">
\t\t{{ post.title }}
\t</a>
</li>
{% endfor %}
{% endfor %}

{% else %}
<h3>{{ year }}</h3>
<!-- Show months in the year with how many posts they have -->
{% for month, posts in archive[year]|reverse(true) %}
<h5>
\t<a href=\"/blog/archive/{{year}}/{{month}}\">
\t\t{{ date(year ~ '-' ~ month ~ '-01')|date('F') }} ({{ posts|length }})
\t</a>
</h5>
{% endfor %}

{% endif %}
{% else %}
<!-- Show the entire archive -->
{% for year, months in archive %}
<h3>{{ year }}</h3>
{% for month, posts in months|reverse(true) %}
<h5>
\t<a href=\"/blog/archive/{{year}}/{{month}}\">
\t\t{{ date(year ~ '-' ~ month ~ '-01')|date('F') }} ({{ posts|length }})
\t</a>
</h5>
{% endfor %}
{% endfor %}
{% endif %}

{% endblock content %}", "blog_showarchive.html.twig", "/var/www/symfony/testnew/templates/blog_showarchive.html.twig");
    }
}
