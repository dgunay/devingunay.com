<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog_showposts.html.twig */
class __TwigTemplate_080bb89202caa20a1fc845a2e8ec9296043a2e66653e3fac6c4f7a4524658e88 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "blog_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog_showposts.html.twig"));

        $this->parent = $this->loadTemplate("blog_base.html.twig", "blog_showposts.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 4, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 5
            echo "<!-- Render the post -->
";
            // line 6
            $this->loadTemplate("post.html.twig", "blog_showposts.html.twig", 6)->display(twig_array_merge($context, ["post" => $context["post"]]));
            // line 7
            echo "<hr />
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "
<!-- Prev/Next links -->
<div class=\"row justify-content-between\">
  <div class=\"col-sm-1\">
    ";
        // line 13
        if ((array_key_exists("prev", $context) &&  !(null === (isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 13, $this->source); })())))) {
            // line 14
            echo "    <a href=\"/blog/post/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["prev"]) || array_key_exists("prev", $context) ? $context["prev"] : (function () { throw new RuntimeError('Variable "prev" does not exist.', 14, $this->source); })()), "publishTime", [], "any", false, false, false, 14), "html", null, true);
            echo "\">Previous</a>
    ";
        }
        // line 16
        echo "  </div>
  <!-- <div class=\"col-sm-1\"></div> -->
  <div class=\"col-sm-1\">
    ";
        // line 19
        if ((array_key_exists("next", $context) &&  !(null === (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 19, $this->source); })())))) {
            // line 20
            echo "    <a href=\"/blog/post/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["next"]) || array_key_exists("next", $context) ? $context["next"] : (function () { throw new RuntimeError('Variable "next" does not exist.', 20, $this->source); })()), "publishTime", [], "any", false, false, false, 20), "html", null, true);
            echo "\">Next</a>
    ";
        }
        // line 22
        echo "  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog_showposts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 22,  117 => 20,  115 => 19,  110 => 16,  104 => 14,  102 => 13,  96 => 9,  81 => 7,  79 => 6,  76 => 5,  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"blog_base.html.twig\" %}

{% block content %}
{% for post in posts %}
<!-- Render the post -->
{% include \"post.html.twig\" with { \"post\" : post } %}
<hr />
{% endfor %}

<!-- Prev/Next links -->
<div class=\"row justify-content-between\">
  <div class=\"col-sm-1\">
    {% if prev is defined and prev is not null %}
    <a href=\"/blog/post/{{prev.publishTime}}\">Previous</a>
    {% endif %}
  </div>
  <!-- <div class=\"col-sm-1\"></div> -->
  <div class=\"col-sm-1\">
    {% if next is defined and next is not null %}
    <a href=\"/blog/post/{{next.publishTime}}\">Next</a>
    {% endif %}
  </div>
</div>
{% endblock content %}", "blog_showposts.html.twig", "/var/www/symfony/testnew/templates/blog_showposts.html.twig");
    }
}
