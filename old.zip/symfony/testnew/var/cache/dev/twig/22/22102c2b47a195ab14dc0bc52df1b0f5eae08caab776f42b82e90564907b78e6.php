<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* minecraft_uptime.html.twig */
class __TwigTemplate_c75324b456ee9d4fd101e682eb9581c65429678fa1ac3d245795542a44217e11 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "minecraft_uptime.html.twig"));

        // line 1
        if ((isset($context["server"]) || array_key_exists("server", $context) ? $context["server"] : (function () { throw new RuntimeError('Variable "server" does not exist.', 1, $this->source); })())) {
            // line 2
            $context["badge"] = "success";
            // line 3
            $context["status"] = "Up";
        } else {
            // line 5
            $context["badge"] = "danger";
            // line 6
            $context["status"] = "Down";
        }
        // line 8
        echo "
<span class=\"navbar-text\">
  Minecraft server status:
  <span class=\"badge badge-";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["badge"]) || array_key_exists("badge", $context) ? $context["badge"] : (function () { throw new RuntimeError('Variable "badge" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "</span>
</span>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "minecraft_uptime.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 11,  52 => 8,  49 => 6,  47 => 5,  44 => 3,  42 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if server %}
{% set badge = \"success\" %}
{% set status = \"Up\" %}
{% else %}
{% set badge = \"danger\" %}
{% set status = \"Down\" %}
{% endif %}

<span class=\"navbar-text\">
  Minecraft server status:
  <span class=\"badge badge-{{badge}}\">{{status}}</span>
</span>", "minecraft_uptime.html.twig", "/var/www/symfony/testnew/templates/minecraft_uptime.html.twig");
    }
}
