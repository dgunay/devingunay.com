<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* about.html.twig */
class __TwigTemplate_e272f9164dcd4011d82f2f130a61890f973947f54d22d0cc6c586c1db5ab73ce extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "about.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "about.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 3
        echo "About Devin
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 7
        $this->displayParentBlock("body", $context, $blocks);
        echo "
<div class=\"jumbotron\">
  <div class=\"container\">
    <h1 class=\"display-3\">
      About Devin
    </h1>
  </div>
</div>
<div class=\"container\">

  <div class=\"row mb-5\">
    <div class=\"col-lg-6\">
      <h1>The Man</h1>
      <p>Devin Gunay is a software engineer. Former PHP developer for
        <a href=\"http://feedonomics.com/\">Feedonomics.</a>
        In his spare time he likes to code, play jazz piano, and play videogames,
        particularly Smash Ultimate.
      </p>

      <p>
        Devin is currently getting his Masters in Computer Science online from
        Georgia Tech while working full time.
      </p>
    </div>
    <div class=\"col-lg-6\">
      <h1>The Programmer</h1>
      <p>
        Website lovingly made with Symfony 4.2 and Bootstrap 4.
      </p>
      <p>
        <a href=\"https://github.com/dgunay/good-bans\">GoodBans</a> and the
        <a href=\"https://github.com/dgunay/flat-file-blog\">blog backend</a> are
        available on GitHub.
      </p>
      <p>
        In addition to PHP, Devin (unfortunately) knows a quite a bit of Perl
        and C++.
      </p>
    </div>
  </div>

  <div class=\"row\">
    <div class=\"col-lg-6\">
      <h1>The Smasher</h1>
      <p>Going by Devin May Cry when he chooses to drown in pools, Devin likes
        to play Marth, Ganondorf, and Chrom/Roy in Super Smash Bros. Ultimate.
        Hit him up on <a href=\"https://twitter.com/devingunay\">Twitter</a> if
        you would like wifi matches.
      </p>
    </div>

    <div class=\"col-lg-6\">
      <h1>The Musician</h1>
      <p>
        Devin is and has been (emphasis on the has-been) many musical things, including:
        <ul>
          <li>A washed-up jazz pianist.</li>
          <li>A washed-up score arranger, especially in the <a href=\"http://gmeatucla.com/\">VGM scene</a>.</li>
          <li>A piano teacher who was never good enough to become washed-up.</li>
          <li>Possibly the worst trumpet player in Los Angeles.</li>
        </ul>
      </p>
    </div>
  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "about.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 7,  68 => 6,  60 => 3,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block title %}
About Devin
{% endblock %}

{% block body %}
{{ parent() }}
<div class=\"jumbotron\">
  <div class=\"container\">
    <h1 class=\"display-3\">
      About Devin
    </h1>
  </div>
</div>
<div class=\"container\">

  <div class=\"row mb-5\">
    <div class=\"col-lg-6\">
      <h1>The Man</h1>
      <p>Devin Gunay is a software engineer. Former PHP developer for
        <a href=\"http://feedonomics.com/\">Feedonomics.</a>
        In his spare time he likes to code, play jazz piano, and play videogames,
        particularly Smash Ultimate.
      </p>

      <p>
        Devin is currently getting his Masters in Computer Science online from
        Georgia Tech while working full time.
      </p>
    </div>
    <div class=\"col-lg-6\">
      <h1>The Programmer</h1>
      <p>
        Website lovingly made with Symfony 4.2 and Bootstrap 4.
      </p>
      <p>
        <a href=\"https://github.com/dgunay/good-bans\">GoodBans</a> and the
        <a href=\"https://github.com/dgunay/flat-file-blog\">blog backend</a> are
        available on GitHub.
      </p>
      <p>
        In addition to PHP, Devin (unfortunately) knows a quite a bit of Perl
        and C++.
      </p>
    </div>
  </div>

  <div class=\"row\">
    <div class=\"col-lg-6\">
      <h1>The Smasher</h1>
      <p>Going by Devin May Cry when he chooses to drown in pools, Devin likes
        to play Marth, Ganondorf, and Chrom/Roy in Super Smash Bros. Ultimate.
        Hit him up on <a href=\"https://twitter.com/devingunay\">Twitter</a> if
        you would like wifi matches.
      </p>
    </div>

    <div class=\"col-lg-6\">
      <h1>The Musician</h1>
      <p>
        Devin is and has been (emphasis on the has-been) many musical things, including:
        <ul>
          <li>A washed-up jazz pianist.</li>
          <li>A washed-up score arranger, especially in the <a href=\"http://gmeatucla.com/\">VGM scene</a>.</li>
          <li>A piano teacher who was never good enough to become washed-up.</li>
          <li>Possibly the worst trumpet player in Los Angeles.</li>
        </ul>
      </p>
    </div>
  </div>
</div>
{% endblock %}", "about.html.twig", "/var/www/symfony/testnew/templates/about.html.twig");
    }
}
