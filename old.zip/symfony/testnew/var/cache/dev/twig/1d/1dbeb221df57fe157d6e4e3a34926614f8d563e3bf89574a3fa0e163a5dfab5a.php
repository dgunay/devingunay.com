<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* goodbans.html.twig */
class __TwigTemplate_34084a891c8da301413ac06ec19f8c72fea2a124107dbb9b9be0bec248f775a5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'navbar' => [$this, 'block_navbar'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "goodbans.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "goodbans.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        $this->displayBlock('navbar', $context, $blocks);
        // line 6
        echo "
<div class=\"jumbotron\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md\">
        <h1 class=\"display-2\"> Good Bans </h1>
      </div>
    </div>
    <div class=\"row\">
      <div class=\"col-md\">
        <p class=\"lead\">A basic reimplementation of
          <a href=\"http://BestBans.com\">BestBans.com</a>,
          which has been out of service since January 2017.
        </p>
        <h5>Terminology:</h5>
        <ul>
          <li><b>Winrate</b>: percentage of the time the champion wins the match.</li>
          <li><b>Adjusted Pickrate</b>: Pickrate weighted by banrate.</li>
          <li><b>Ban Value</b>: How banworthy GoodBans rates the champion.</li>
        </ul>

      </div>
    </div>
  </div>
</div>

<div class=\"container\">
  <div class=\"row justify-content-md-center\">
    <div class=\"col-md-8\">
      <h2 class=\"display-2\">
        Patch ";
        // line 36
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["bans"]) || array_key_exists("bans", $context) ? $context["bans"] : (function () { throw new RuntimeError('Variable "bans" does not exist.', 36, $this->source); })()), "getPatch", [], "any", false, false, false, 36), "html", null, true);
        echo " Top Bans
      </h2>
    </div>
  </div>

  ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["bans"]) || array_key_exists("bans", $context) ? $context["bans"] : (function () { throw new RuntimeError('Variable "bans" does not exist.', 41, $this->source); })()), "getTopBans", [], "any", false, false, false, 41));
        foreach ($context['_seq'] as $context["elo"] => $context["topBans"]) {
            // line 42
            echo "  ";
            // line 43
            echo "  <div class=\"row justify-content-md-left\" style=\"margin-top:20px\">
    <h4 class=\"display-4\">
      ";
            // line 45
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, twig_lower_filter($this->env, $context["elo"])), "html", null, true);
            echo "
    </h4>
  </div>
  <hr class=\"hr-primary\" style=\"background-color:black;\">

  ";
            // line 51
            echo "  <div class=\"row\">
    ";
            // line 52
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["topBans"]);
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["champion"]) {
                // line 53
                echo "    <div class=\"col-sm\">

      <div class=\"card\">
        <img src=\"";
                // line 56
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["champion"], "img", [], "array", false, false, false, 56), "html", null, true);
                echo "\" class=\"card-img-top\" />
        <div class=\"card-header\">
          <h5> #";
                // line 58
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 58), "html", null, true);
                echo ": ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["champion"], "name", [], "any", false, false, false, 58), "html", null, true);
                echo " </h5>
        </div>
        <ul class=\"list-group list-group-flush\">
          <li class=\"list-group-item\">
            Winrate: ";
                // line 62
                echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->source, $context["champion"], "winRate", [], "any", false, false, false, 62) * 100), "html", null, true);
                echo "%
          </li>
          <li class=\"list-group-item\">
            Adj. Pickrate: ";
                // line 65
                echo twig_escape_filter($this->env, twig_round((twig_get_attribute($this->env, $this->source, $context["champion"], "adjustedPickRate", [], "any", false, false, false, 65) * 100), 2, "common"), "html", null, true);
                echo "%
          </li>
          <li class=\"list-group-item list-group-item-success\">
            <b>
              Ban value: ";
                // line 69
                echo twig_escape_filter($this->env, twig_round((twig_get_attribute($this->env, $this->source, $context["champion"], "banValue", [], "any", false, false, false, 69) * 10000), 2, "common"), "html", null, true);
                echo "
            </b>
          </li>
        </ul>
      </div>

    </div>
    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['champion'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 77
            echo "  </div>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['elo'], $context['topBans'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 79
        echo "</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "navbar"));

        // line 4
        $this->displayParentBlock("navbar", $context, $blocks);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "goodbans.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 4,  210 => 3,  201 => 79,  194 => 77,  172 => 69,  165 => 65,  159 => 62,  150 => 58,  145 => 56,  140 => 53,  123 => 52,  120 => 51,  112 => 45,  108 => 43,  106 => 42,  102 => 41,  94 => 36,  62 => 6,  60 => 3,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block body %}
{% block navbar %}
{{ parent() }}
{% endblock %}

<div class=\"jumbotron\">
  <div class=\"container\">
    <div class=\"row\">
      <div class=\"col-md\">
        <h1 class=\"display-2\"> Good Bans </h1>
      </div>
    </div>
    <div class=\"row\">
      <div class=\"col-md\">
        <p class=\"lead\">A basic reimplementation of
          <a href=\"http://BestBans.com\">BestBans.com</a>,
          which has been out of service since January 2017.
        </p>
        <h5>Terminology:</h5>
        <ul>
          <li><b>Winrate</b>: percentage of the time the champion wins the match.</li>
          <li><b>Adjusted Pickrate</b>: Pickrate weighted by banrate.</li>
          <li><b>Ban Value</b>: How banworthy GoodBans rates the champion.</li>
        </ul>

      </div>
    </div>
  </div>
</div>

<div class=\"container\">
  <div class=\"row justify-content-md-center\">
    <div class=\"col-md-8\">
      <h2 class=\"display-2\">
        Patch {{bans.getPatch}} Top Bans
      </h2>
    </div>
  </div>

  {% for elo, topBans in bans.getTopBans %}
  {# Display the elo #}
  <div class=\"row justify-content-md-left\" style=\"margin-top:20px\">
    <h4 class=\"display-4\">
      {{ elo|lower|capitalize }}
    </h4>
  </div>
  <hr class=\"hr-primary\" style=\"background-color:black;\">

  {# Display the champions #}
  <div class=\"row\">
    {% for champion in topBans %}
    <div class=\"col-sm\">

      <div class=\"card\">
        <img src=\"{{champion['img']}}\" class=\"card-img-top\" />
        <div class=\"card-header\">
          <h5> #{{loop.index}}: {{champion.name}} </h5>
        </div>
        <ul class=\"list-group list-group-flush\">
          <li class=\"list-group-item\">
            Winrate: {{champion.winRate * 100}}%
          </li>
          <li class=\"list-group-item\">
            Adj. Pickrate: {{(champion.adjustedPickRate * 100)|round(2, 'common')}}%
          </li>
          <li class=\"list-group-item list-group-item-success\">
            <b>
              Ban value: {{(champion.banValue * 10000)|round(2, 'common')}}
            </b>
          </li>
        </ul>
      </div>

    </div>
    {% endfor %}
  </div>
  {% endfor %}
</div>

{% endblock body %}", "goodbans.html.twig", "/var/www/symfony/testnew/templates/goodbans.html.twig");
    }
}
